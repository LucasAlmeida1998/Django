from django.http import HttpResponse

def Projeto(request):
	return HttpResponse(
	"<h1 style='color:green'>Olá Mundo! Nova Criação com Django")